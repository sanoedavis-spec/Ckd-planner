\
/* CKD Diet Plan Generator (Static) - rule-based
   - IndexedDB storage
   - Deterministic rules engine + 3-day builder
   - PDF via print-to-PDF (browser)
*/
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));
const uid = () => (crypto?.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2));
const todayIso = () => new Date().toISOString().slice(0,10);
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const fmt = (n, d=0) => (Number.isFinite(n) ? Number(n).toFixed(d) : "-");

const DEFAULT_RULES = {
  meta: { name: "Default (KDIGO/KDOQI-aligned) v1", version: 1 },
  kcalPerKgByActivity: { sedentary: 25, moderate: 30, active: 35 },
  proteinGPerKg: { non_dialysis_default: 0.8, non_dialysis_low_protein: 0.6, hd: 1.2, pd: 1.3 },
  sodiumTargetMg: 1500,
  labThresholds: {
    potassium_mmol_l: { low: 3.5, high: 5.5, critical: 6.0 },
    phosphorus_mg_dl: { low: 2.5, high: 4.5 },
    sodium_meq_l: { low: 135, high: 145 }
  },
  labFreshnessDaysWarn: 30,
  fluidsMlByStage: {
    "1": 2500, "2": 2500, "3a": 2000, "3b": 2000, "4": 1500, "5": 1200,
    "dialysis_hd": 1000, "dialysis_pd": 1500, "aki": 1500
  },
  carbsPerMealG: { breakfast: 45, lunch: 60, dinner: 60 },
  foodCutoffs: { potassium_mg_per_serving_strict: 200, phosphorus_mg_per_serving_strict: 150, sodium_mg_per_serving_strict: 140 },
  portionRounding: { cup_step: 0.5, g_step: 25, piece_step: 0.5 }
};

const DEFAULT_TEMPLATE = {
  name: "Fixed 3-meal template (CKD+DM+HTN)",
  json: { meals: { breakfast: ["grain","protein","fruit"], lunch: ["grain","protein","veg"], dinner: ["grain","protein","veg"] } }
};

const KENYA_FOODS = [
  { id:"ke-grain-ugali", country:"Kenya", name:"Ugali (plain)", category:"grain", unit:"cup", base_qty:1, calories:220, protein_g:4, carbs_g:48, fat_g:1, fiber_g:2, sodium_mg:10, potassium_mg:60, phosphorus_mg:50, tags:["gluten"], max_portion_qty:2 },
  { id:"ke-grain-rice", country:"Kenya", name:"Rice (cooked)", category:"grain", unit:"cup", base_qty:1, calories:206, protein_g:4, carbs_g:45, fat_g:0.4, fiber_g:0.6, sodium_mg:2, potassium_mg:55, phosphorus_mg:68, tags:[], max_portion_qty:2 },
  { id:"ke-grain-chapati", country:"Kenya", name:"Chapati", category:"grain", unit:"piece", base_qty:1, calories:180, protein_g:4, carbs_g:24, fat_g:8, fiber_g:2, sodium_mg:170, potassium_mg:80, phosphorus_mg:70, tags:["gluten","fatty","processed"], max_portion_qty:2 },
  { id:"ke-prot-fish", country:"Kenya", name:"Fish (tilapia) cooked", category:"protein", unit:"g", base_qty:100, calories:128, protein_g:26, carbs_g:0, fat_g:3, fiber_g:0, sodium_mg:60, potassium_mg:380, phosphorus_mg:200, tags:["high_p","high_k"], max_portion_qty:150 },
  { id:"ke-prot-chicken", country:"Kenya", name:"Chicken (skinless) cooked", category:"protein", unit:"g", base_qty:100, calories:165, protein_g:31, carbs_g:0, fat_g:4, fiber_g:0, sodium_mg:70, potassium_mg:256, phosphorus_mg:210, tags:["high_p","high_k"], max_portion_qty:150 },
  { id:"ke-prot-eggs", country:"Kenya", name:"Egg", category:"protein", unit:"piece", base_qty:1, calories:78, protein_g:6, carbs_g:0.6, fat_g:5, fiber_g:0, sodium_mg:62, potassium_mg:63, phosphorus_mg:95, tags:["high_p"], max_portion_qty:2 },
  { id:"ke-prot-ndengu", country:"Kenya", name:"Ndengu (green grams) cooked", category:"protein", unit:"cup", base_qty:1, calories:212, protein_g:14, carbs_g:38, fat_g:0.8, fiber_g:15, sodium_mg:10, potassium_mg:730, phosphorus_mg:280, tags:["high_k","high_p"], max_portion_qty:1 },
  { id:"ke-veg-sukuma", country:"Kenya", name:"Sukuma wiki cooked", category:"veg", unit:"cup", base_qty:1, calories:40, protein_g:3, carbs_g:7, fat_g:0.5, fiber_g:3, sodium_mg:30, potassium_mg:250, phosphorus_mg:50, tags:["high_k"], max_portion_qty:1.5 },
  { id:"ke-veg-cabbage", country:"Kenya", name:"Cabbage cooked", category:"veg", unit:"cup", base_qty:1, calories:35, protein_g:2, carbs_g:8, fat_g:0.2, fiber_g:3, sodium_mg:20, potassium_mg:170, phosphorus_mg:40, tags:[], max_portion_qty:2 },
  { id:"ke-veg-carrot", country:"Kenya", name:"Carrots cooked", category:"veg", unit:"cup", base_qty:1, calories:55, protein_g:1, carbs_g:12, fat_g:0.3, fiber_g:4, sodium_mg:90, potassium_mg:410, phosphorus_mg:50, tags:["high_k"], max_portion_qty:1 },
  { id:"ke-fruit-apple", country:"Kenya", name:"Apple", category:"fruit", unit:"piece", base_qty:1, calories:95, protein_g:0.5, carbs_g:25, fat_g:0.3, fiber_g:4, sodium_mg:1, potassium_mg:195, phosphorus_mg:20, tags:[], max_portion_qty:2 },
  { id:"ke-fruit-banana", country:"Kenya", name:"Banana", category:"fruit", unit:"piece", base_qty:1, calories:105, protein_g:1.3, carbs_g:27, fat_g:0.4, fiber_g:3, sodium_mg:1, potassium_mg:420, phosphorus_mg:25, tags:["high_k"], max_portion_qty:1 },
  { id:"ke-dairy-milk", country:"Kenya", name:"Milk (whole)", category:"dairy", unit:"cup", base_qty:1, calories:149, protein_g:8, carbs_g:12, fat_g:8, fiber_g:0, sodium_mg:105, potassium_mg:322, phosphorus_mg:233, tags:["high_p","high_k"], max_portion_qty:1 },
  { id:"ke-other-water", country:"Kenya", name:"Water", category:"other", unit:"ml", base_qty:250, calories:0, protein_g:0, carbs_g:0, fat_g:0, fiber_g:0, sodium_mg:0, potassium_mg:0, phosphorus_mg:0, tags:["fluid"], max_portion_qty:3000 }
];

const DB_NAME = "ckdDietStatic";
const DB_VER = 1;

function idbOpen(){
  return new Promise((resolve, reject)=>{
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = ()=>{
      const db = req.result;
      const mk = (name) => db.objectStoreNames.contains(name) ? null : db.createObjectStore(name, { keyPath:"id" });
      mk("foods"); mk("rules"); mk("templates"); mk("patients"); mk("labs"); mk("plans"); mk("plan_items"); mk("overrides");
    };
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error);
  });
}

async function put(store, value){
  const db = await idbOpen();
  return new Promise((resolve, reject)=>{
    const t = db.transaction(store,"readwrite");
    const s = t.objectStore(store);
    const r = s.put(value);
    r.onsuccess=()=>resolve(true);
    r.onerror=()=>reject(r.error);
  });
}
async function get(store, key){
  const db = await idbOpen();
  return new Promise((resolve, reject)=>{
    const t = db.transaction(store,"readonly");
    const s = t.objectStore(store);
    const r = s.get(key);
    r.onsuccess=()=>resolve(r.result||null);
    r.onerror=()=>reject(r.error);
  });
}
async function all(store){
  const db = await idbOpen();
  return new Promise((resolve, reject)=>{
    const t = db.transaction(store,"readonly");
    const s = t.objectStore(store);
    const r = s.getAll();
    r.onsuccess=()=>resolve(r.result||[]);
    r.onerror=()=>reject(r.error);
  });
}
async function clearStore(name){
  const db = await idbOpen();
  return new Promise((resolve, reject)=>{
    const t = db.transaction(name,"readwrite");
    const s = t.objectStore(name);
    const r = s.clear();
    r.onsuccess=()=>resolve(true);
    r.onerror=()=>reject(r.error);
  });
}

async function seed(){
  if ((await all("foods")).length===0) for (const f of KENYA_FOODS) await put("foods", f);
  if ((await all("rules")).length===0) await put("rules", { id:"rules-1", ...DEFAULT_RULES });
  if ((await all("templates")).length===0) await put("templates", { id:"tpl-1", ...DEFAULT_TEMPLATE });
}

function daysBetween(aIso, bIso){
  const a = new Date(aIso), b = new Date(bIso);
  return Math.floor(Math.abs(b-a)/(1000*60*60*24));
}

function computeFlags(latestLab, rules){
  const thr = rules.labThresholds;
  const flags = { labFreshnessWarning:false, potassium:"unknown", phosphorus:"unknown", sodium:"unknown", strictK:false, strictP:false, strictNa:false };
  if (!latestLab) return flags;
  flags.labFreshnessWarning = daysBetween(latestLab.collected_at, todayIso()) > (rules.labFreshnessDaysWarn||30);

  const k = latestLab.potassium_mmol_l;
  if (Number.isFinite(k)){
    if (k >= thr.potassium_mmol_l.critical) flags.potassium="critical";
    else if (k >= thr.potassium_mmol_l.high) flags.potassium="high";
    else if (k < thr.potassium_mmol_l.low) flags.potassium="low";
    else flags.potassium="normal";
  }
  const p = latestLab.phosphorus_mg_dl;
  if (Number.isFinite(p)){
    if (p > thr.phosphorus_mg_dl.high) flags.phosphorus="high";
    else if (p < thr.phosphorus_mg_dl.low) flags.phosphorus="low";
    else flags.phosphorus="normal";
  }
  const na = latestLab.sodium_meq_l;
  if (Number.isFinite(na)){
    if (na > thr.sodium_meq_l.high) flags.sodium="high";
    else if (na < thr.sodium_meq_l.low) flags.sodium="low";
    else flags.sodium="normal";
  }
  flags.strictK = (flags.potassium==="high"||flags.potassium==="critical");
  flags.strictP = (flags.phosphorus==="high");
  flags.strictNa = (flags.sodium==="high");
  return flags;
}

function computeTargets(patient, rules){
  const kcalPerKg = rules.kcalPerKgByActivity[patient.activity_level] || 30;
  const calories = Math.round(kcalPerKg * patient.weight_kg);
  let proteinPerKg = rules.proteinGPerKg.non_dialysis_default;
  if (patient.ckd_stage==="dialysis_hd") proteinPerKg = rules.proteinGPerKg.hd;
  if (patient.ckd_stage==="dialysis_pd") proteinPerKg = rules.proteinGPerKg.pd;
  const proteinG = Math.round(proteinPerKg * patient.weight_kg);
  const sodiumMg = rules.sodiumTargetMg;
  const fluidsMl = (rules.fluidsMlByStage && rules.fluidsMlByStage[patient.ckd_stage]) ? rules.fluidsMlByStage[patient.ckd_stage] : 2000;
  const potassiumMg = String(patient.ckd_stage||"").startsWith("dialysis") ? 3000 : 2500;
  const phosphorusMg = String(patient.ckd_stage||"").startsWith("dialysis") ? 1000 : 800;
  return { calories, proteinG, sodiumMg, potassiumMg, phosphorusMg, fluidsMl };
}

function foodBlockedByAllergy(food, allergies){
  const a = new Set((allergies||[]).map(x=>String(x).toLowerCase().trim()).filter(Boolean));
  const tags = new Set((food.tags||[]).map(x=>String(x).toLowerCase()));
  for (const item of a) if (tags.has(item)) return true;
  return false;
}
function foodBlockedByStrictFlags(food, flags, rules){
  const cut = rules.foodCutoffs;
  if (flags.strictK && food.potassium_mg > cut.potassium_mg_per_serving_strict) return true;
  if (flags.strictP && food.phosphorus_mg > cut.phosphorus_mg_per_serving_strict) return true;
  if (flags.strictNa && food.sodium_mg > cut.sodium_mg_per_serving_strict) return true;
  return false;
}
function scoreFood(food){ return food.potassium_mg*1.0 + food.phosphorus_mg*1.0 + food.sodium_mg*0.5; }
function roundPortion(food, qty, rules){
  const r = rules.portionRounding || {};
  if (food.unit==="cup"){ const step = r.cup_step ?? 0.5; return Math.max(step, Math.round(qty/step)*step); }
  if (food.unit==="g"){ const step = r.g_step ?? 25; return Math.max(step, Math.round(qty/step)*step); }
  if (food.unit==="piece"){ const step = r.piece_step ?? 0.5; return Math.max(step, Math.round(qty/step)*step); }
  return Math.max(0.5, Math.round(qty*2)/2);
}
function scaleNutrients(food, qty){
  const f = qty / food.base_qty;
  return { calories:food.calories*f, protein_g:food.protein_g*f, carbs_g:food.carbs_g*f, fat_g:food.fat_g*f, fiber_g:food.fiber_g*f,
    sodium_mg:food.sodium_mg*f, potassium_mg:food.potassium_mg*f, phosphorus_mg:food.phosphorus_mg*f };
}
function pickBest(list){ return list.sort((a,b)=>scoreFood(a)-scoreFood(b))[0] || null; }

function build3DayPlan({foods, patient, targets, flags, rules, template}){
  const meals = template.json.meals;
  const basePool = foods.filter(f=>f.country==="Kenya")
    .filter(f=>!foodBlockedByAllergy(f, patient.allergies))
    .filter(f=>!foodBlockedByStrictFlags(f, flags, rules));
  const days = [0,1,2].map(day_index=>{
    const items=[];
    ["breakfast","lunch","dinner"].forEach(mealName=>{
      meals[mealName].forEach(slot=>{
        const candidates = basePool.filter(f=>f.category===slot);
        const picked = pickBest([...candidates]);
        if (!picked) return;
        const mealCalTarget = targets.calories/3;
        const mealProteinTarget = targets.proteinG/3;
        const carbTarget = (rules.carbsPerMealG && rules.carbsPerMealG[mealName]) ? rules.carbsPerMealG[mealName] : 45;
        let portion = picked.base_qty;
        if (picked.category==="grain"||picked.category==="fruit"){
          portion = picked.base_qty * (carbTarget / Math.max(1, picked.carbs_g));
        } else if (picked.category==="protein"){
          portion = picked.base_qty * (mealProteinTarget / Math.max(1, picked.protein_g));
        }
        const nutrients = scaleNutrients(picked, portion);
        const calFactor = mealCalTarget / Math.max(50, nutrients.calories);
        portion = portion * clamp(calFactor, 0.8, 1.2);
        if (Number.isFinite(picked.max_portion_qty)) portion = Math.min(portion, picked.max_portion_qty);
        portion = roundPortion(picked, portion, rules);
        items.push({ id:uid(), plan_id:null, day_index, meal_name:mealName, food_id:picked.id, portion_qty:portion, unit:picked.unit, computed: scaleNutrients(picked, portion) });
      });
    });
    return { day_index, items };
  });
  const totals = { calories:0, protein_g:0, carbs_g:0, fat_g:0, fiber_g:0, sodium_mg:0, potassium_mg:0, phosphorus_mg:0 };
  days.forEach(d=>d.items.forEach(it=> Object.keys(totals).forEach(k=> totals[k]+=(it.computed[k]||0))));
  Object.keys(totals).forEach(k=> totals[k]=Math.round((totals[k]/3)*10)/10);
  return { days, totals };
}

let STATE = { currentTab:"dashboard", selectedPatientId:null, selectedPlanId:null };

function showTab(name){
  STATE.currentTab=name;
  $$(".tab").forEach(t=>t.classList.toggle("active", t.dataset.tab===name));
  ["dashboard","patient","plan","admin"].forEach(v=> $("#view-"+v).style.display = (v===name) ? "" : "none");
}

$$(".tab").forEach(t=>t.addEventListener("click", async ()=>{
  showTab(t.dataset.tab);
  if (t.dataset.tab==="dashboard") await renderDashboard();
  if (t.dataset.tab==="patient") await renderPatient();
  if (t.dataset.tab==="plan") await renderPlan();
  if (t.dataset.tab==="admin") await renderAdmin("rules");
}));

async function renderDashboard(){
  const q = ($("#searchPatients").value||"").trim().toLowerCase();
  const patients = await all("patients");
  const filtered = q ? patients.filter(p=>String(p.full_name||"").toLowerCase().includes(q)) : patients;
  const tbody = $("#patientsTbody");
  tbody.innerHTML="";
  filtered.forEach(p=>{
    const tr=document.createElement("tr");
    tr.innerHTML = `<td>${esc(p.full_name||"")}</td><td>${esc(p.ckd_stage||"-")}</td><td>${p.egfr ?? "-"}</td><td><button class="btn" data-open="${p.id}">Open</button></td>`;
    tbody.appendChild(tr);
  });
  $("#patientsEmpty").style.display = patients.length ? "none" : "";
  tbody.querySelectorAll("button[data-open]").forEach(btn=> btn.addEventListener("click", async ()=>{
    STATE.selectedPatientId = btn.dataset.open;
    showTab("patient");
    await renderPatient();
  }));
}
$("#searchPatients").addEventListener("input", ()=>renderDashboard());

$("#btnNewPatient").addEventListener("click", async ()=>{
  const id=uid();
  await put("patients", { id, full_name:"New Patient", sex:"female", age_years:40, weight_kg:70, height_cm:165, activity_level:"sedentary", allergies:[], ckd_stage:"3a", egfr:45, created_at:new Date().toISOString() });
  STATE.selectedPatientId=id;
  showTab("patient");
  await renderPatient();
});
$("#btnBackToDash1").addEventListener("click", ()=>{ showTab("dashboard"); renderDashboard(); });

function patientFormHtml(p){
  const opt = (cur,val,label)=>`<option value="${val}" ${String(cur)===String(val)?"selected":""}>${label||val}</option>`;
  return `
    <label>Full name</label><input class="input" id="p_full_name" value="${escAttr(p.full_name||"")}">
    <div class="grid cols2">
      <div><label>Sex</label><select class="input" id="p_sex">${opt(p.sex,"female")}${opt(p.sex,"male")}${opt(p.sex,"other")}</select></div>
      <div><label>Age (years)</label><input class="input" id="p_age" type="number" value="${p.age_years}"></div>
    </div>
    <div class="grid cols2">
      <div><label>Weight (kg)</label><input class="input" id="p_weight" type="number" value="${p.weight_kg}"></div>
      <div><label>Height (cm)</label><input class="input" id="p_height" type="number" value="${p.height_cm}"></div>
    </div>
    <label>Activity level</label><select class="input" id="p_activity">${opt(p.activity_level,"sedentary")}${opt(p.activity_level,"moderate")}${opt(p.activity_level,"active")}</select>
    <label>CKD stage/workflow</label>
    <select class="input" id="p_stage">
      ${opt(p.ckd_stage,"1","Stage 1")}${opt(p.ckd_stage,"2","Stage 2")}${opt(p.ckd_stage,"3a","Stage 3a")}${opt(p.ckd_stage,"3b","Stage 3b")}${opt(p.ckd_stage,"4","Stage 4")}${opt(p.ckd_stage,"5","Stage 5")}
      ${opt(p.ckd_stage,"dialysis_hd","Dialysis (HD)")}${opt(p.ckd_stage,"dialysis_pd","Dialysis (PD)")}${opt(p.ckd_stage,"aki","AKI")}
    </select>
    <label>eGFR (manual override)</label><input class="input" id="p_egfr" type="number" value="${p.egfr ?? ""}" placeholder="e.g., 45">
    <label>Allergies (comma separated tags)</label><input class="input" id="p_allergies" value="${escAttr((p.allergies||[]).join(", "))}" placeholder="e.g., gluten, dairy">
  `;
}
function bindPatientForm(p){
  const save = async (key,val)=>{ await put("patients", { ...p, [key]: val }); };
  $("#p_full_name").oninput = e=>save("full_name", e.target.value);
  $("#p_sex").onchange = e=>save("sex", e.target.value);
  $("#p_age").oninput = e=>save("age_years", Number(e.target.value||0));
  $("#p_weight").oninput = e=>save("weight_kg", Number(e.target.value||0));
  $("#p_height").oninput = e=>save("height_cm", Number(e.target.value||0));
  $("#p_activity").onchange = e=>save("activity_level", e.target.value);
  $("#p_stage").onchange = e=>save("ckd_stage", e.target.value);
  $("#p_egfr").oninput = e=>save("egfr", e.target.value ? Number(e.target.value) : null);
  $("#p_allergies").oninput = e=>save("allergies", e.target.value.split(",").map(x=>x.trim()).filter(Boolean));
}
function renderFlagsBox(flags, targets){
  $("#flagsBox").innerHTML = `
    <div class="item">
      <div class="muted">Flags</div>
      <div>K: <b>${flags.potassium}</b> | P: <b>${flags.phosphorus}</b> | Na: <b>${flags.sodium}</b></div>
      ${flags.labFreshnessWarning ? `<div style="color:var(--danger)">Labs may be outdated.</div>` : ``}
      <div class="muted small">Strict filters: K=${flags.strictK?"YES":"No"}, P=${flags.strictP?"YES":"No"}, Na=${flags.strictNa?"YES":"No"}</div>
    </div>
    <div class="item">
      <div class="muted">Targets</div>
      <div class="muted small">Calories ${targets.calories} kcal/day</div>
      <div class="muted small">Protein ${targets.proteinG} g/day</div>
      <div class="muted small">Sodium ${targets.sodiumMg} mg/day</div>
    </div>`;
}
async function renderPatient(){
  const id = STATE.selectedPatientId;
  if (!id){ $("#patientForm").innerHTML = `<div class="muted">No patient selected. Go to Dashboard.</div>`; return; }
  const patient = await get("patients", id);
  if (!patient){ $("#patientForm").innerHTML = `<div class="muted">Patient not found.</div>`; return; }
  const rules = (await all("rules"))[0] || { id:"rules-1", ...DEFAULT_RULES };
  const tpl = (await all("templates"))[0] || { id:"tpl-1", ...DEFAULT_TEMPLATE };
  const foods = await all("foods");
  const labs = (await all("labs")).filter(l=>l.patient_id===id).sort((a,b)=>a.collected_at.localeCompare(b.collected_at));
  const latestLab = labs[labs.length-1] || null;
  const flags = computeFlags(latestLab, rules);
  const targets = computeTargets(patient, rules);

  $("#patientForm").innerHTML = patientFormHtml(patient);
  bindPatientForm(patient);
  renderFlagsBox(flags, targets);
  renderLabsTable(labs);

  $("#btnAddLab").onclick = async ()=>{
    await put("labs", { id:uid(), patient_id:id, collected_at:todayIso(), potassium_mmol_l:4.5, phosphorus_mg_dl:4.0, sodium_meq_l:138 });
    await renderPatient();
  };
  $("#btnGeneratePlan").onclick = async ()=>{
    $("#patientMsg").textContent = "Generating…";
    const built = build3DayPlan({ foods, patient, targets, flags, rules, template: tpl });
    const planId = uid();
    await put("plans", { id:planId, patient_id:id, start_date:todayIso(), days:3, targets, flags, summary:{ totalsPerDay: built.totals }, created_at:new Date().toISOString() });
    for (const d of built.days) for (const it of d.items) await put("plan_items", { ...it, plan_id: planId });
    STATE.selectedPlanId = planId;
    $("#patientMsg").textContent = "Done.";
    showTab("plan");
    await renderPlan();
  };
}

function renderLabsTable(labs){
  const tbody=$("#labsTbody"); tbody.innerHTML="";
  labs.forEach(l=>{
    const tr=document.createElement("tr");
    tr.innerHTML = `
      <td><input class="input" data-lab="${l.id}" data-k="collected_at" value="${escAttr(l.collected_at)}"></td>
      <td><input class="input" type="number" data-lab="${l.id}" data-k="potassium_mmol_l" value="${l.potassium_mmol_l ?? ""}"></td>
      <td><input class="input" type="number" data-lab="${l.id}" data-k="phosphorus_mg_dl" value="${l.phosphorus_mg_dl ?? ""}"></td>
      <td><input class="input" type="number" data-lab="${l.id}" data-k="sodium_meq_l" value="${l.sodium_meq_l ?? ""}"></td>`;
    tbody.appendChild(tr);
  });
  $("#labsEmpty").style.display = labs.length ? "none" : "";
  tbody.querySelectorAll("input[data-lab]").forEach(inp=>{
    inp.addEventListener("input", async ()=>{
      const lab = await get("labs", inp.dataset.lab);
      if (!lab) return;
      const key = inp.dataset.k;
      const v = (key==="collected_at") ? inp.value : (inp.value===""? null : Number(inp.value));
      await put("labs", { ...lab, [key]: v });
      await renderPatient();
    });
  });
}

async function renderPlan(){
  const planId = STATE.selectedPlanId;
  if (!planId){ $("#planMeta").textContent = "No plan selected. Generate one from Patient page."; return; }
  const plan = await get("plans", planId);
  if (!plan){ $("#planMeta").textContent = "Plan not found."; return; }
  const patient = await get("patients", plan.patient_id);
  const foods = await all("foods");
  const foodMap = Object.fromEntries(foods.map(f=>[f.id,f]));
  const items = (await all("plan_items")).filter(x=>x.plan_id===planId);
  const overrides = (await all("overrides")).filter(x=>x.plan_id===planId).sort((a,b)=>a.applied_at.localeCompare(b.applied_at));

  $("#planMeta").textContent = `Patient: ${patient?.full_name || "-"} • Start: ${plan.start_date} • 3 days`;
  $("#planKpis").innerHTML = `
    <div class="item"><div class="muted">Targets</div>
      <div class="muted small">Calories ${plan.targets.calories} kcal/day</div>
      <div class="muted small">Protein ${plan.targets.proteinG} g/day</div>
      <div class="muted small">Sodium ${plan.targets.sodiumMg} mg/day</div>
    </div>
    <div class="item"><div class="muted">Flags</div>
      <div class="muted small">K ${plan.flags.potassium} | P ${plan.flags.phosphorus} | Na ${plan.flags.sodium}</div>
      <div class="muted small">Strict: K ${plan.flags.strictK} P ${plan.flags.strictP} Na ${plan.flags.strictNa}</div>
    </div>
    <div class="item"><div class="muted">Estimated totals/day</div>
      <div class="muted small">Calories ${fmt(plan.summary.totalsPerDay.calories,0)} kcal</div>
      <div class="muted small">Protein ${fmt(plan.summary.totalsPerDay.protein_g,0)} g</div>
      <div class="muted small">Na ${fmt(plan.summary.totalsPerDay.sodium_mg,0)} mg</div>
    </div>`;
  const tbody=$("#planItemsTbody"); tbody.innerHTML="";
  items.sort((a,b)=> (a.day_index-b.day_index)||a.meal_name.localeCompare(b.meal_name)).forEach(it=>{
    const food = foodMap[it.food_id];
    const tr=document.createElement("tr");
    tr.innerHTML = `<td>${it.day_index+1}</td><td>${esc(it.meal_name)}</td><td>${esc(food?.name || it.food_id)}</td><td>${fmt(it.portion_qty, it.unit==="g"?0:1)} ${esc(it.unit)}</td><td><button class="btn" data-ov="${it.id}">Add override</button></td>`;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll("button[data-ov]").forEach(btn=>btn.addEventListener("click", async ()=>{
    const item = items.find(x=>x.id===btn.dataset.ov);
    if (!item) return;
    const reason = prompt("Override reason (required):");
    if (!reason) return;
    await put("overrides", { id:uid(), plan_id:planId, day_index:item.day_index, meal_name:item.meal_name, food_id:item.food_id, reason, applied_by:"dietitian", applied_at:new Date().toISOString() });
    await renderPlan();
  }));
  renderOverrides(overrides, foodMap);

  $("#btnBackToPatient").onclick = ()=>{ showTab("patient"); renderPatient(); };
  $("#btnPdf").onclick = ()=>{
    const html = buildPrintableReport({ patient, plan, items, foodMap, overrides });
    const w = window.open("", "_blank");
    w.document.open(); w.document.write(html); w.document.close();
  };
}
function renderOverrides(overrides, foodMap){
  const box=$("#overridesList"); box.innerHTML="";
  if (!overrides.length){ box.innerHTML = `<div class="muted">No overrides.</div>`; return; }
  overrides.forEach(ov=>{
    const f = foodMap[ov.food_id]||{};
    const div=document.createElement("div");
    div.className="card"; div.style.marginTop="10px";
    div.innerHTML = `<div class="muted">Day ${ov.day_index+1} ${esc(ov.meal_name)} — Food: ${esc(f.name||ov.food_id)}</div>
      <div>Reason: ${esc(ov.reason)}</div><div class="muted small">By: ${esc(ov.applied_by)} — ${esc(ov.applied_at)}</div>`;
    box.appendChild(div);
  });
}

async function renderAdmin(which){
  const adminArea=$("#adminArea");
  const rules = (await all("rules"))[0] || { id:"rules-1", ...DEFAULT_RULES };
  const foods = await all("foods");
  const tpls = await all("templates");
  const setMsg=(m)=>$("#adminMsg").textContent=m||"";

  if (which==="rules"){
    adminArea.innerHTML = `<label>Rules JSON</label><textarea class="input" id="adminRules" style="min-height:420px">${escTa(JSON.stringify(rules,null,2))}</textarea>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="saveRules">Save rules</button></div>`;
    $("#saveRules").onclick = async ()=>{
      try{ const parsed=JSON.parse($("#adminRules").value); await put("rules", parsed); setMsg("Rules saved."); }
      catch{ setMsg("Rules JSON invalid."); }
    };
  }
  if (which==="foods"){
    adminArea.innerHTML = `<label>Foods JSON</label><textarea class="input" id="adminFoods" style="min-height:420px">${escTa(JSON.stringify(foods,null,2))}</textarea>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="saveFoods">Save foods</button></div>`;
    $("#saveFoods").onclick = async ()=>{
      try{ const parsed=JSON.parse($("#adminFoods").value); await clearStore("foods"); for (const f of parsed) await put("foods", f); setMsg("Foods saved."); }
      catch{ setMsg("Foods JSON invalid."); }
    };
  }
  if (which==="tpl"){
    adminArea.innerHTML = `<label>Templates JSON</label><textarea class="input" id="adminTpl" style="min-height:420px">${escTa(JSON.stringify(tpls,null,2))}</textarea>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="saveTpl">Save templates</button></div>`;
    $("#saveTpl").onclick = async ()=>{
      try{ const parsed=JSON.parse($("#adminTpl").value); await clearStore("templates"); for (const t of parsed) await put("templates", t); setMsg("Templates saved."); }
      catch{ setMsg("Templates JSON invalid."); }
    };
  }
}
$("#adminTabRules").addEventListener("click", ()=>renderAdmin("rules"));
$("#adminTabFoods").addEventListener("click", ()=>renderAdmin("foods"));
$("#adminTabTpl").addEventListener("click", ()=>renderAdmin("tpl"));

$("#btnReset").addEventListener("click", async ()=>{
  if (!confirm("This will delete all local data (patients, plans, foods edits). Continue?")) return;
  await new Promise((resolve,reject)=>{ const r=indexedDB.deleteDatabase(DB_NAME); r.onsuccess=()=>resolve(true); r.onerror=()=>reject(r.error); });
  location.reload();
});
$("#btnExport").addEventListener("click", async ()=>{
  const dump = { exported_at:new Date().toISOString(), foods:await all("foods"), rules:await all("rules"), templates:await all("templates"),
    patients:await all("patients"), labs:await all("labs"), plans:await all("plans"), plan_items:await all("plan_items"), overrides:await all("overrides") };
  const blob = new Blob([JSON.stringify(dump,null,2)], {type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a"); a.href=url; a.download=`ckd-diet-backup-${todayIso()}.json`; a.click();
  URL.revokeObjectURL(url);
});

function updateOffline(){
  const online = navigator.onLine;
  $("#offlinePill").textContent = "Offline: " + (online ? "No (online)" : "YES");
  $("#offlinePill").style.borderColor = online ? "var(--border)" : "var(--ok)";
}
window.addEventListener("online", updateOffline);
window.addEventListener("offline", updateOffline);

function buildPrintableReport({ patient, plan, items, foodMap, overrides }){
  const byDay = [0,1,2].map(d=> items.filter(i=>i.day_index===d).sort((a,b)=>a.meal_name.localeCompare(b.meal_name)));
  const rows = byDay.map((arr, idx)=>{
    const lines = arr.map(it=>{
      const f = foodMap[it.food_id] || {};
      const qty = fmt(it.portion_qty, it.unit==="g"?0:1);
      return `<div><b>${esc(it.meal_name.toUpperCase())}</b>: ${esc(f.name||it.food_id)} — ${qty} ${esc(it.unit)}</div>`;
    }).join("");
    return `<h3>Day ${idx+1}</h3>${lines}`;
  }).join("");

  const ov = overrides.length ? overrides.map(o=>{
    const f = foodMap[o.food_id] || {};
    return `<div style="margin-bottom:8px">
      <div><b>Day ${o.day_index+1} ${esc(o.meal_name)}</b> — ${esc(f.name||o.food_id)}</div>
      <div>Reason: ${esc(o.reason)}</div>
      <div style="color:#666;font-size:12px">By ${esc(o.applied_by)} • ${esc(o.applied_at)}</div>
    </div>`;
  }).join("") : `<div>No overrides applied.</div>`;

  const totals = plan.summary?.totalsPerDay || {};
  return `<!doctype html><html><head><meta charset="UTF-8"><title>CKD Diet Plan Report</title>
  <style>body{font-family:Arial,sans-serif;padding:24px;color:#111}.muted{color:#555}.box{border:1px solid #ddd;border-radius:10px;padding:14px;margin:10px 0}h1{margin:0 0 6px}h2{margin:18px 0 8px}h3{margin:12px 0 6px}@media print{button{display:none}}</style>
  </head><body>
    <button onclick="window.print()">Print / Save as PDF</button>
    <h1>CKD Diet Plan Report (Rule‑based)</h1>
    <div class="muted">Start date: ${plan.start_date} • Duration: 3 days</div>
    <div class="box">
      <h2>Patient Summary</h2>
      <div><b>Name:</b> ${esc(patient.full_name||"-")}</div>
      <div><b>Age:</b> ${patient.age_years} • <b>Sex:</b> ${esc(patient.sex)}</div>
      <div><b>Weight:</b> ${fmt(patient.weight_kg,1)} kg • <b>Height:</b> ${fmt(patient.height_cm,0)} cm • <b>Activity:</b> ${esc(patient.activity_level)}</div>
      <div><b>Stage/workflow:</b> ${esc(patient.ckd_stage)} • <b>eGFR:</b> ${patient.egfr ?? "-"}</div>
      <div><b>Allergies:</b> ${esc((patient.allergies||[]).join(", ") || "None")}</div>
    </div>
    <div class="box">
      <h2>Biochemical Flags</h2>
      <div><b>K:</b> ${esc(plan.flags.potassium)} • <b>P:</b> ${esc(plan.flags.phosphorus)} • <b>Na:</b> ${esc(plan.flags.sodium)}</div>
      <div><b>Lab freshness warning:</b> ${plan.flags.labFreshnessWarning ? "YES" : "No"}</div>
      <div><b>Strict filters:</b> K=${plan.flags.strictK?"YES":"No"}, P=${plan.flags.strictP?"YES":"No"}, Na=${plan.flags.strictNa?"YES":"No"}</div>
    </div>
    <div class="box">
      <h2>Targets (per day)</h2>
      <div>Calories: ${plan.targets.calories} kcal</div>
      <div>Protein: ${plan.targets.proteinG} g</div>
      <div>Sodium: ${plan.targets.sodiumMg} mg</div>
      <div>Potassium (soft): ${plan.targets.potassiumMg} mg</div>
      <div>Phosphorus (soft): ${plan.targets.phosphorusMg} mg</div>
      <div>Fluids: ${plan.targets.fluidsMl} ml</div>
    </div>
    <div class="box"><h2>3‑Day Meal Plan</h2>${rows}</div>
    <div class="box">
      <h2>Estimated Daily Totals (from generated plan)</h2>
      <div>Calories: ${fmt(totals.calories,0)} kcal</div>
      <div>Protein: ${fmt(totals.protein_g,0)} g • Carbs: ${fmt(totals.carbs_g,0)} g</div>
      <div>Sodium: ${fmt(totals.sodium_mg,0)} mg • Potassium: ${fmt(totals.potassium_mg,0)} mg • Phosphorus: ${fmt(totals.phosphorus_mg,0)} mg</div>
    </div>
    <div class="box"><h2>Overrides / Audit Trail</h2>${ov}</div>
    <div class="box"><h2>Clinician Notes</h2>
      <div style="height:80px;border:1px dashed #bbb;border-radius:8px"></div>
      <div style="margin-top:14px">Signature: ____________________  Date: ____________</div>
    </div>
  </body></html>`;
}

function esc(s){ return String(s??"").replace(/[&<>"']/g, c=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c])); }
function escAttr(s){ return esc(s).replace(/"/g,"&quot;"); }
function escTa(s){ return String(s??"").replace(/</g,"&lt;"); }

(async function boot(){
  await seed();
  updateOffline();
  showTab("dashboard");
  await renderDashboard();
})();
