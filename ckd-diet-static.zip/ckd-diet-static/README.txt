CKD Diet Plan Generator (Static HTML/CSS/JS - No Node.js)

HOW TO RUN
1) Open the folder.
2) Double-click index.html (opens in your browser).
3) Optional: Install as app (PWA):
   - Chrome: Menu (3 dots) -> Cast, save, and share -> Install page as app

OFFLINE
- Works offline after first load if served over http(s).
- If you open index.html directly from file://, some browsers may limit service workers.
  The app still works as a normal offline file app (your data stays in the browser).

DATA STORAGE
- All data is stored locally in your browser (IndexedDB).
- No cloud sync/auth in this static version.

PDF
- Click "Generate PDF" -> printable report opens in a new tab.
- Click "Print / Save as PDF" -> choose "Save as PDF".

FILES
- index.html
- styles.css
- app.js
- manifest.webmanifest
- sw.js
- assets/ (icons)
